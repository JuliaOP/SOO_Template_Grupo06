package br.unesp.rc.mqttexample;

import java.io.IOException;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Main {
    public static void main(String[] args) throws IOException {
        String topic        = "MQTT Examples";
        String content      = "Unesp - SOO 2020";
        int qos             = 2; // Garantia de entrega: deve receber uma e única vez
        String broker       = "tcp://mqtt.eclipse.org:1883";
        String clientId     = "SOO-349875cvn8345"; // Deve ser único no Broker
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            // Conecta ao Broker
            MqttClient client = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("Connecting to broker: " + broker);
            client.connect(connOpts);
            System.out.println("Connected");
            
            
            // Increve em um tópico
            MqttCallback callback;
            callback = new MqttCallbackExample();
            
            System.out.println("Subscribing to: " + topic);
            client.subscribe(topic);
            client.setCallback(callback);
            
            
            // Envia uma mensagem
            System.out.println("Publishing message: " + content);
            MqttMessage message = new MqttMessage(content.getBytes());
            message.setQos(qos);
            client.publish(topic, message);
            System.out.println("Message published");
            
            System.in.read();
            
            
            // Desconecta do Broker
            client.disconnect();
            System.out.println("Disconnected");
            client.close();
        } catch(MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
    }
}
