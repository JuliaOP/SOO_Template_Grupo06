package br.unesp.rc.mqttexample;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MqttCallbackExample implements MqttCallback {
    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println("Message received: " + message);
    }

    @Override
    public void connectionLost(Throwable cause) {
        // Se algum erro acontecer, podemos ver o que causou mais facilmente
        cause.printStackTrace();
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken imdt) {
        // Nós não precisamos disso ainda
    }
}
