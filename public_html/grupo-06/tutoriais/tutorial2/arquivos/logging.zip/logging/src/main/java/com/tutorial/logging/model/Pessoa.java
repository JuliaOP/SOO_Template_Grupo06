package com.tutorial.logging.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class Pessoa {
    private final int id;
    private final String nome;
}
