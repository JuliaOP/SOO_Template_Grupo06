package com.tutorial.logging.services.impl;

import com.tutorial.logging.model.Pessoa;
import com.tutorial.logging.services.PessoaService;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Log4j2
public class PessoaServiceImpl implements PessoaService {
    private static List<Pessoa> DB = new ArrayList<>();

    @Override
    public Pessoa add(Pessoa pessoa) {
        if (DB.stream().anyMatch(p -> p.getId() == pessoa.getId())){
            log.warn("Tentativa de inserção duplicada");
            return null;
        }

        log.info("Pessoa Inserida");
        DB.add(pessoa);
        return pessoa;
    }

    @Override
    public Pessoa getById(int id) {
        if (!DB.stream().anyMatch(p -> p.getId() == id)){
            log.warn("Tentativa de recuperação por ID inexistente");
            return null;
        }

        log.info("Pessoa Recuperada por ID");
        return DB.stream()
                .filter(p -> p.getId() == id)
                .findFirst().get();
    }

    @Override
    public List<Pessoa> getAll() {
        log.info("Todas As Pessoas Recuperadas");
        return DB;
    }
}
