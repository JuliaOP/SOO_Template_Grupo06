package com.tutorial.logging.services;

import com.tutorial.logging.model.Pessoa;
import java.util.List;

public interface PessoaService {
    Pessoa add(Pessoa pessoa);
    Pessoa getById(int id);
    List<Pessoa> getAll();
}
