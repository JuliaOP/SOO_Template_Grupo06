package com.tutorial.logging.resources;

import com.tutorial.logging.model.Pessoa;
import com.tutorial.logging.services.PessoaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pessoa")
public class PessoaController {
    private final PessoaService pessoaService;

    @Autowired
    public PessoaController(PessoaService pessoaService) {
        this.pessoaService = pessoaService;
    }

    @PostMapping
    public Pessoa add(@RequestBody Pessoa pessoa){
        return this.pessoaService.add(pessoa);
    }

    @GetMapping("/{id}")
    public Pessoa getById(@PathVariable("id") int id){
        return this.pessoaService.getById(id);
    }

    @GetMapping
    public List<Pessoa> getAll(){
        return this.pessoaService.getAll();
    }

}
