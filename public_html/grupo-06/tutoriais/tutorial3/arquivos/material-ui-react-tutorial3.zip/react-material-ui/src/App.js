import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import sensoresData from './sensores.json';
import img from './background.jpeg';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    backgroundImage: `url(${img})`
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary
  },
  title: {
    padding: 15,
    color: 'white'
  },
  cardList: {
    margin: 5
  }
}));

const semana = {
  1: "segunda",
  2: "terca",
  3: "quarta",
  4: "quinta",
  5: "sexta",
  6: "sabado",
  7: "domingo"
}
export default function FullWidthGrid() {
  const classes = useStyles();
  const [selected, setSelected] = useState(0);
  console.log(sensoresData)
  return (
    <div className={classes.root}>
      <h1 className={classes.title}>Relatório diario</h1>
      <Grid container
        direction="row"
        justify="center"
        alignItems="flex-start"
        spacing={3}>
        <Grid item xs={3}>
          <Paper className={classes.paper}>
            {sensoresData.map((item) => {
              return <Card className={classes.cardList} onClick={() => setSelected(item)}>
                <CardContent >
                  <Typography gutterBottom variant="h5" component="h2">
                    {`Semana: ${item.semana + 1} - ${semana[item.dia]}`}
                  </Typography>
                </CardContent>
              </Card>
            })}
          </Paper>
        </Grid>
        <Grid item xs={3} >
          <Paper className={classes.paper}>
            {selected ? <Card >
              <CardContent>
                <Typography gutterBottom variant="h5" component="h2">
                  {`Semana: ${selected.semana + 1} - ${semana[selected.dia]}`}
                </Typography>
                <Typography variant="h5" component="h2">
                  {`🌡 temperatura: ${selected.sensores.temperatura}`}
                </Typography>
                <Typography variant="h5" component="h2">
                  {`⛲ agua: ${selected.sensores.humidade}`}
                </Typography>
                <Typography variant="h5" component="h2">
                  {`💧 umidade: ${selected.sensores.agua}`}
                </Typography>
                <Typography variant="h5" component="h2">
                  {`⚡ energia: ${selected.sensores.eletricidade}`}
                </Typography>
              </CardContent>
            </Card> : <div>Nao selecionado</div>}
          </Paper>
        </Grid>

      </Grid>
    </div>
  );
}