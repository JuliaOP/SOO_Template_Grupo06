package com.grupo06.greeno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenoApplicationTests {

    @Test
    void contextLoads() {
    }

}
