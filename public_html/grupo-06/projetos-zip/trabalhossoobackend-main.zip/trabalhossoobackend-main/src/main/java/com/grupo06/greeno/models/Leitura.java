package com.grupo06.greeno.models;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@RequiredArgsConstructor
@Getter
public class Leitura {
    private String tipoSensor;
    private LocalDateTime data;
    private Double valor;

    @Override
    public String toString() {
        return "Leitura{" +
                "tipoSensor='" + tipoSensor + '\'' +
                ", data=" + data +
                ", valor=" + valor +
                '}';
    }
}
