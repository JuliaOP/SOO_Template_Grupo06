package com.grupo06.greeno.repository.impl;

import com.grupo06.greeno.repository.SensoresRepository;
import com.grupo06.greeno.repository.models.DiaRepositoryModel;
import com.grupo06.greeno.repository.models.LeituraRepositoryModel;
import com.grupo06.greeno.repository.models.MesRepositoryModel;
import com.grupo06.greeno.repository.models.SensorRepositoryModel;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Log4j2
@Repository
public class SensoresRepositoryImpl implements SensoresRepository {
    private final static List<SensorRepositoryModel> DB = new ArrayList<>();
    private static int lastSensorID = -1;

    @Override
    public boolean addSensor(String tipoSensor) {
        boolean retorno = false;

        if (DB.stream().noneMatch(s -> s.getTipoSensor().equals(tipoSensor))){
            log.info(String.format("Criando Novo Sensor %s", tipoSensor));
            DB.add(new SensorRepositoryModel( ++lastSensorID,tipoSensor));
            retorno = true;
        }

        return retorno;
    }

    @Override
    public boolean add(LeituraRepositoryModel leitura, String tipoSensor) {
        if (DB.stream().noneMatch(s -> s.getTipoSensor().equals(tipoSensor))){
            log.warn(String.format("Sensor %s não cadastrado", tipoSensor));
            return false;
        }

        var sensor = DB.stream()
                .filter(s -> s.getTipoSensor().equals(tipoSensor))
                .findFirst().orElse(null);

        assert sensor != null;
        if (sensor.getMeses().stream().noneMatch(m -> m.getMes() == leitura.getHorario().getMonth())){
            log.info("Criando Novo Mes");
            sensor.getMeses().add(new MesRepositoryModel(leitura.getHorario().getMonth()));
        }

        var mes = sensor.getMeses().stream()
                .filter(m -> m.getMes() == leitura.getHorario().getMonth())
                .findFirst().orElse(null);

        assert mes != null;
        if (mes.getDias().stream().noneMatch(m -> m.getDia() == leitura.getHorario().getDayOfMonth())){
            log.info("Criando Novo Dia");
            mes.getDias().add(new DiaRepositoryModel(leitura.getHorario().getDayOfMonth()));
        }

        return Objects.requireNonNull(mes.getDias().stream()
                .filter(d -> d.getDia() == leitura.getHorario().getDayOfMonth())
                .findFirst().orElse(null))
                .getLeituras().add(leitura);
    }

    @Override
    public List<LeituraRepositoryModel> getLeituraPerDay(LocalDateTime dia, String tipoSensor) {
        return Objects.requireNonNull(DB.stream()
                .filter(s -> s.getTipoSensor().equals(tipoSensor))
                .flatMap(s -> s.getMeses().stream())
                .filter(m -> m.getMes() == dia.getMonth())
                .flatMap(m -> m.getDias().stream())
                .filter(d -> d.getDia() == dia.getDayOfMonth())
                .findFirst().orElse(null)).getLeituras();
    }

    @Override
    public List<DiaRepositoryModel> getLeituraPerMonth(LocalDateTime dia, String tipoSensor) {
        return DB.stream()
                .filter(s -> s.getTipoSensor().equals(tipoSensor))
                .flatMap(s -> s.getMeses().stream())
                .filter(m -> m.getMes() == dia.getMonth())
                .flatMap(m -> m.getDias().stream()).collect(Collectors.toList());
    }

    @Override
    public LeituraRepositoryModel getLastLeitura(String tipoSensor) {
        return DB.stream()
                .filter(s -> s.getTipoSensor().equals(tipoSensor))
                .flatMap(s -> s.getMeses().stream())
                .flatMap(m -> m.getDias().stream())
                .flatMap(d -> d.getLeituras().stream())
                .max(Comparator.comparing(LeituraRepositoryModel::getHorario)).orElse(null);
    }

    @Override
    public List<String> listSensors() {
        return DB.stream()
                .map(s -> s.getTipoSensor())
                .collect(Collectors.toList());
    }
}
