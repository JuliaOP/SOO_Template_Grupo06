package com.grupo06.greeno.repository.models;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@AllArgsConstructor
@Getter
public class LeituraRepositoryModel {
    private double valor;
    private LocalDateTime horario;
}
