package com.grupo06.greeno.repository;

import com.grupo06.greeno.repository.models.DiaRepositoryModel;
import com.grupo06.greeno.repository.models.LeituraRepositoryModel;
import com.grupo06.greeno.repository.models.SensorRepositoryModel;

import java.time.LocalDateTime;
import java.util.List;

public interface SensoresRepository {
    boolean addSensor(String tipoSensor);
    List<String> listSensors();
    boolean add(LeituraRepositoryModel leitura, String tipoSensor);
    List<LeituraRepositoryModel> getLeituraPerDay(LocalDateTime dia, String tipoSensor);
    List<DiaRepositoryModel> getLeituraPerMonth(LocalDateTime dia, String tipoSensor);
    LeituraRepositoryModel getLastLeitura(String tipoSensor);
}
