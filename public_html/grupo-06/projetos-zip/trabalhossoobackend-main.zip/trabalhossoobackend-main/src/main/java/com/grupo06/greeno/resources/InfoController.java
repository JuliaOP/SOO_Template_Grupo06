package com.grupo06.greeno.resources;

import com.grupo06.greeno.models.Leitura;
import com.grupo06.greeno.models.viewModels.LeituraViewModel;
import com.grupo06.greeno.services.SensoresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/info")
public class InfoController {
    private final SensoresService service;

    @Autowired
    public InfoController(SensoresService service) {
        this.service = service;
    }

    @GetMapping("/mes")
    public List<LeituraViewModel> getLeiturasPerMonth(@RequestBody Leitura leitura) {
        return this.service.getLeituraPerMonth(leitura);
    }

    @GetMapping("/dia")
    public List<LeituraViewModel> getLeiturasPerDay(@RequestBody Leitura leitura) {
        return this.service.getLeituraPerDay(leitura);
    }

    @GetMapping("/tempo-real")
    public LeituraViewModel getLastTemperatura(@RequestBody Leitura leitura){
        return this.service.getLastLeitura(leitura);
    }
}
