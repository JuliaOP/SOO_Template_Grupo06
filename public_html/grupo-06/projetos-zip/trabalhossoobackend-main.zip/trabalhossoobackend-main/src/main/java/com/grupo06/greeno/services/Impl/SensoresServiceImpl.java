package com.grupo06.greeno.services.Impl;

import com.grupo06.greeno.models.Leitura;
import com.grupo06.greeno.models.Sensor;
import com.grupo06.greeno.models.viewModels.LeituraViewModel;
import com.grupo06.greeno.models.viewModels.SensorViewModel;
import com.grupo06.greeno.repository.SensoresRepository;
import com.grupo06.greeno.repository.models.LeituraRepositoryModel;
import com.grupo06.greeno.services.SensoresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SensoresServiceImpl implements SensoresService {
    private final SensoresRepository repository;

    @Autowired
    public SensoresServiceImpl(SensoresRepository repository) {
        this.repository = repository;
    }

    @Override
    public Leitura add(Leitura leitura) {
        if (this.repository.add(new LeituraRepositoryModel(leitura.getValor(), leitura.getData()), leitura.getTipoSensor())){
            return leitura;
        }
        return null;
    }

    @Override
    public boolean add(List<Leitura> leituras) {
        var retorno = true;
        try {
            for (Leitura leitura:
                    leituras) {
                this.repository.add(new LeituraRepositoryModel(leitura.getValor(), leitura.getData()), leitura.getTipoSensor());
            }
        }
        catch (Exception e) {
            retorno = false;
        }

        return retorno;
    }

    @Override
    public List<LeituraViewModel> getLeituraPerMonth(Leitura leitura){
        return this.repository.getLeituraPerMonth(leitura.getData(), leitura.getTipoSensor()).stream()
                .map(d -> new LeituraViewModel(leitura.getTipoSensor(),
                        d.getLeituras().stream().mapToDouble(LeituraRepositoryModel::getValor).average().getAsDouble(),
                        d.getDia()))
                .collect(Collectors.toList());
    }

    @Override
    public List<LeituraViewModel> getLeituraPerDay(Leitura leitura){
        return this.repository.getLeituraPerDay(leitura.getData(), leitura.getTipoSensor()).stream()
                .map(d -> new LeituraViewModel(leitura.getTipoSensor(),
                        d.getValor(),
                        d.getHorario().getDayOfMonth()))
                .collect(Collectors.toList());
    }

    @Override
    public LeituraViewModel getLastLeitura(Leitura leitura) {
        LeituraRepositoryModel l = this.repository.getLastLeitura(leitura.getTipoSensor());

        return l != null ? new LeituraViewModel(leitura.getTipoSensor(), l.getValor(), 0) : null;
    }

    @Override
    public List<SensorViewModel> listAllSensors() {
        return this.repository.listSensors()
                .stream()
                .map(s -> new SensorViewModel(s))
                .collect(Collectors.toList());
    }

    @Override
    public boolean addSensor(Sensor sensor) {
        return this.repository.addSensor(sensor.getTipo());
    }
}
