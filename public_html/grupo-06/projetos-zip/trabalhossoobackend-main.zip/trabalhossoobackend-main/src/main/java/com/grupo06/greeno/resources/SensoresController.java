package com.grupo06.greeno.resources;

import com.grupo06.greeno.models.Leitura;
import com.grupo06.greeno.models.Sensor;
import com.grupo06.greeno.models.viewModels.SensorViewModel;
import com.grupo06.greeno.services.SensoresService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sensores")
@Log4j2
public class SensoresController {
    public SensoresService service;

    @Autowired
    public SensoresController(SensoresService service) {
        this.service = service;
    }

    @PostMapping("/leitura")
    public Leitura add(@RequestBody Leitura leitura){
        log.info(leitura);

        this.service.add(leitura);

        return leitura;
    }

    @GetMapping
    public List<SensorViewModel> listSensors() {
        return this.service.listAllSensors();
    }

    @PostMapping
    public boolean addSensor(@RequestBody Sensor sensor) {
        return this.service.addSensor(sensor);
    }


    @PostMapping("/leituras/lote")
    public boolean add(@RequestBody List<Leitura> leituras){
        return this.service.add(leituras);
    }
}
