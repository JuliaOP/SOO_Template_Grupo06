package com.grupo06.greeno.models.viewModels;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class SensorViewModel {
    // private final int id;
    // private String nome;
    private String tipo;
}
