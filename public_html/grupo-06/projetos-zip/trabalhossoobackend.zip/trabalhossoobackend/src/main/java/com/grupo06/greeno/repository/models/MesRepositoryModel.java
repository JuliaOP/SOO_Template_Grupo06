package com.grupo06.greeno.repository.models;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

@Getter
public class MesRepositoryModel {
    private Month mes;
    private List<DiaRepositoryModel> dias;

    public MesRepositoryModel(Month mes) {
        this.mes = mes;
        this.dias = new ArrayList<>();
    }
}
