package com.grupo06.greeno.models.viewModels;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class LeituraViewModel {
    private final String tipoSensor;
    private final double valor;
    private final int dia;
}
