package com.grupo06.greeno.models;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@RequiredArgsConstructor
@Getter
public class Sensor {
    // private final int id;
    // private String nome;
    private String tipo;

    @Override
    public String toString() {
        return "Sensor{" +
                "tipo='" + tipo + '\'' +
                '}';
    }
}
