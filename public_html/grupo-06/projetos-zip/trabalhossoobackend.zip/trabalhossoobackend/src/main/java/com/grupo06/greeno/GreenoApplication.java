package com.grupo06.greeno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GreenoApplication.class, args);
    }

}
