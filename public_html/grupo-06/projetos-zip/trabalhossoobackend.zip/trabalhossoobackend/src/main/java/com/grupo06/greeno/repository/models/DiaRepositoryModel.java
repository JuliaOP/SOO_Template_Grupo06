package com.grupo06.greeno.repository.models;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class DiaRepositoryModel {
    private int dia;
    private List<LeituraRepositoryModel> leituras;

    public DiaRepositoryModel(int dia){
        this.dia = dia;
        this.leituras = new ArrayList<>();
    }
}
