package com.grupo06.greeno.services;

import com.grupo06.greeno.models.Leitura;
import com.grupo06.greeno.models.Sensor;
import com.grupo06.greeno.models.viewModels.LeituraViewModel;
import com.grupo06.greeno.models.viewModels.SensorViewModel;

import java.util.List;

public interface SensoresService {
    Leitura add(Leitura leitura);

    boolean add(List<Leitura> leituras);

    List<LeituraViewModel> getLeituraPerMonth(Leitura leitura);

    List<LeituraViewModel> getLeituraPerDay(Leitura leitura);

    LeituraViewModel getLastLeitura(Leitura leitura);

    List<SensorViewModel> listAllSensors();

    boolean addSensor(Sensor sensor);
}
